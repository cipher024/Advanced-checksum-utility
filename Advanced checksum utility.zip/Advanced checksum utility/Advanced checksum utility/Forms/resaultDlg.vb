﻿Public Class resaultDlg

    Private Sub resaultDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Settings.ComboBox1.SelectedIndex = 1 Then
            Franch()
        End If
        If Settings.ComboBox2.Text = "Dark" Then

            DarkTheme()
        End If
    End Sub

    Private Sub Md5_Pic_Click(sender As Object, e As EventArgs) Handles Md5_Pic.Click

    End Sub
End Class