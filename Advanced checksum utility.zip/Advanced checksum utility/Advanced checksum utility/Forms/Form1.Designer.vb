﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Img = New System.Windows.Forms.ImageList(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddFolderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddProsesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ClearAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveSelectedItmeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.FsdToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.OpenInVirusTotalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PropriToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BasicToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdvancedToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FindToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.CopyMD5ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopySHA1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA256ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA512ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA384ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RIPEMD160ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyCRC32ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopySelectedItmeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnSelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextHashToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.icontray = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlwaysOnTop = New System.Windows.Forms.ToolStripMenuItem()
        Me.GridLines = New System.Windows.Forms.ToolStripMenuItem()
        Me.AutoResizeColumnsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.Statue = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripDropDownButton1 = New System.Windows.Forms.ToolStripDropDownButton()
        Me.View_Details = New System.Windows.Forms.ToolStripMenuItem()
        Me.View_List = New System.Windows.Forms.ToolStripMenuItem()
        Me.View_LargeIcon = New System.Windows.Forms.ToolStripMenuItem()
        Me.View_Tile = New System.Windows.Forms.ToolStripMenuItem()
        Me.View_SmallIcon = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Files_List = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddFilesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddFolderToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddProcessToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.TextHashToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyMD5ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopySHAToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA1ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA256ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA384ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SHA512ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyCRC32ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyCRC32ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopySelectedItmeToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HTMLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SFVToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerifyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerifySelectedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerfyAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerfyFromAFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.OpenInVirusTotalToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PropertiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdvancedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.RemoveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectedItmeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearAllToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.isAlive = New System.Windows.Forms.Timer(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ContextMenuStrip2 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Img
        '
        Me.Img.ColorDepth = System.Windows.Forms.ColorDepth.Depth32Bit
        Me.Img.ImageSize = New System.Drawing.Size(25, 25)
        Me.Img.TransparentColor = System.Drawing.Color.Transparent
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.OptionToolStripMenuItem, Me.ViewToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.MenuStrip1.Size = New System.Drawing.Size(871, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddFilesToolStripMenuItem, Me.AddFolderToolStripMenuItem, Me.AddProsesToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ToolStripSeparator1, Me.ClearAllToolStripMenuItem, Me.RemoveSelectedItmeToolStripMenuItem, Me.ToolStripSeparator2, Me.FsdToolStripMenuItem, Me.ToolStripSeparator3, Me.OpenInVirusTotalToolStripMenuItem, Me.PropriToolStripMenuItem, Me.ToolStripSeparator4, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'AddFilesToolStripMenuItem
        '
        Me.AddFilesToolStripMenuItem.Image = CType(resources.GetObject("AddFilesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddFilesToolStripMenuItem.Name = "AddFilesToolStripMenuItem"
        Me.AddFilesToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.AddFilesToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.AddFilesToolStripMenuItem.Text = "Add Files"
        '
        'AddFolderToolStripMenuItem
        '
        Me.AddFolderToolStripMenuItem.Image = CType(resources.GetObject("AddFolderToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddFolderToolStripMenuItem.Name = "AddFolderToolStripMenuItem"
        Me.AddFolderToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.AddFolderToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.AddFolderToolStripMenuItem.Text = "Add Folder"
        '
        'AddProsesToolStripMenuItem
        '
        Me.AddProsesToolStripMenuItem.Image = CType(resources.GetObject("AddProsesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddProsesToolStripMenuItem.Name = "AddProsesToolStripMenuItem"
        Me.AddProsesToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.AddProsesToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.AddProsesToolStripMenuItem.Text = "Add Process"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem8, Me.ToolStripMenuItem11})
        Me.SaveToolStripMenuItem.Image = CType(resources.GetObject("SaveToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.SaveToolStripMenuItem.Text = "Save as"
        '
        'ToolStripMenuItem8
        '
        Me.ToolStripMenuItem8.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem9, Me.ToolStripMenuItem10})
        Me.ToolStripMenuItem8.Image = CType(resources.GetObject("ToolStripMenuItem8.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
        Me.ToolStripMenuItem8.Size = New System.Drawing.Size(149, 22)
        Me.ToolStripMenuItem8.Text = "HTML"
        '
        'ToolStripMenuItem9
        '
        Me.ToolStripMenuItem9.Image = CType(resources.GetObject("ToolStripMenuItem9.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
        Me.ToolStripMenuItem9.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem9.Text = "Save Selected "
        '
        'ToolStripMenuItem10
        '
        Me.ToolStripMenuItem10.Image = CType(resources.GetObject("ToolStripMenuItem10.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
        Me.ToolStripMenuItem10.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem10.Text = "Save All"
        '
        'ToolStripMenuItem11
        '
        Me.ToolStripMenuItem11.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem12, Me.ToolStripMenuItem13})
        Me.ToolStripMenuItem11.Image = CType(resources.GetObject("ToolStripMenuItem11.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem11.Name = "ToolStripMenuItem11"
        Me.ToolStripMenuItem11.Size = New System.Drawing.Size(149, 22)
        Me.ToolStripMenuItem11.Text = "Checksum file"
        '
        'ToolStripMenuItem12
        '
        Me.ToolStripMenuItem12.Image = CType(resources.GetObject("ToolStripMenuItem12.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem12.Name = "ToolStripMenuItem12"
        Me.ToolStripMenuItem12.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem12.Text = "Save Selected "
        '
        'ToolStripMenuItem13
        '
        Me.ToolStripMenuItem13.Image = CType(resources.GetObject("ToolStripMenuItem13.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem13.Name = "ToolStripMenuItem13"
        Me.ToolStripMenuItem13.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem13.Text = "Save All"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(232, 6)
        '
        'ClearAllToolStripMenuItem
        '
        Me.ClearAllToolStripMenuItem.Image = CType(resources.GetObject("ClearAllToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ClearAllToolStripMenuItem.Name = "ClearAllToolStripMenuItem"
        Me.ClearAllToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.ClearAllToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.ClearAllToolStripMenuItem.Text = "Clear list"
        '
        'RemoveSelectedItmeToolStripMenuItem
        '
        Me.RemoveSelectedItmeToolStripMenuItem.Image = CType(resources.GetObject("RemoveSelectedItmeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoveSelectedItmeToolStripMenuItem.Name = "RemoveSelectedItmeToolStripMenuItem"
        Me.RemoveSelectedItmeToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.Delete
        Me.RemoveSelectedItmeToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.RemoveSelectedItmeToolStripMenuItem.Text = "Remove Selected item"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(232, 6)
        '
        'FsdToolStripMenuItem
        '
        Me.FsdToolStripMenuItem.Image = CType(resources.GetObject("FsdToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FsdToolStripMenuItem.Name = "FsdToolStripMenuItem"
        Me.FsdToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.FsdToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.FsdToolStripMenuItem.Text = "Delete selected File"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(232, 6)
        '
        'OpenInVirusTotalToolStripMenuItem
        '
        Me.OpenInVirusTotalToolStripMenuItem.Image = CType(resources.GetObject("OpenInVirusTotalToolStripMenuItem.Image"), System.Drawing.Image)
        Me.OpenInVirusTotalToolStripMenuItem.Name = "OpenInVirusTotalToolStripMenuItem"
        Me.OpenInVirusTotalToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Alt) _
            Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.OpenInVirusTotalToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.OpenInVirusTotalToolStripMenuItem.Text = "Open in VirusTotal"
        '
        'PropriToolStripMenuItem
        '
        Me.PropriToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BasicToolStripMenuItem, Me.AdvancedToolStripMenuItem1})
        Me.PropriToolStripMenuItem.Image = CType(resources.GetObject("PropriToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PropriToolStripMenuItem.Name = "PropriToolStripMenuItem"
        Me.PropriToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.PropriToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.PropriToolStripMenuItem.Text = "Properties"
        '
        'BasicToolStripMenuItem
        '
        Me.BasicToolStripMenuItem.Name = "BasicToolStripMenuItem"
        Me.BasicToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.BasicToolStripMenuItem.Text = "Basic"
        '
        'AdvancedToolStripMenuItem1
        '
        Me.AdvancedToolStripMenuItem1.Name = "AdvancedToolStripMenuItem1"
        Me.AdvancedToolStripMenuItem1.Size = New System.Drawing.Size(127, 22)
        Me.AdvancedToolStripMenuItem1.Text = "Advanced"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(232, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Image = CType(resources.GetObject("ExitToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.[End]), System.Windows.Forms.Keys)
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FindToolStripMenuItem, Me.ToolStripSeparator6, Me.CopyMD5ToolStripMenuItem, Me.CopySHA1ToolStripMenuItem, Me.RIPEMD160ToolStripMenuItem, Me.CopyCRC32ToolStripMenuItem, Me.CopySelectedItmeToolStripMenuItem, Me.ToolStripSeparator5, Me.SelectAllToolStripMenuItem, Me.UnSelectAllToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'FindToolStripMenuItem
        '
        Me.FindToolStripMenuItem.Image = CType(resources.GetObject("FindToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FindToolStripMenuItem.Name = "FindToolStripMenuItem"
        Me.FindToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.FindToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.FindToolStripMenuItem.Text = "Find"
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(173, 6)
        '
        'CopyMD5ToolStripMenuItem
        '
        Me.CopyMD5ToolStripMenuItem.Name = "CopyMD5ToolStripMenuItem"
        Me.CopyMD5ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.CopyMD5ToolStripMenuItem.Text = "Copy MD5"
        '
        'CopySHA1ToolStripMenuItem
        '
        Me.CopySHA1ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SHA1ToolStripMenuItem, Me.SHA256ToolStripMenuItem, Me.SHA512ToolStripMenuItem, Me.SHA384ToolStripMenuItem})
        Me.CopySHA1ToolStripMenuItem.Name = "CopySHA1ToolStripMenuItem"
        Me.CopySHA1ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.CopySHA1ToolStripMenuItem.Text = "Copy SHA"
        '
        'SHA1ToolStripMenuItem
        '
        Me.SHA1ToolStripMenuItem.Name = "SHA1ToolStripMenuItem"
        Me.SHA1ToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.SHA1ToolStripMenuItem.Text = "SHA-1"
        '
        'SHA256ToolStripMenuItem
        '
        Me.SHA256ToolStripMenuItem.Name = "SHA256ToolStripMenuItem"
        Me.SHA256ToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.SHA256ToolStripMenuItem.Text = "SHA-256"
        '
        'SHA512ToolStripMenuItem
        '
        Me.SHA512ToolStripMenuItem.Name = "SHA512ToolStripMenuItem"
        Me.SHA512ToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.SHA512ToolStripMenuItem.Text = "SHA-512"
        '
        'SHA384ToolStripMenuItem
        '
        Me.SHA384ToolStripMenuItem.Name = "SHA384ToolStripMenuItem"
        Me.SHA384ToolStripMenuItem.Size = New System.Drawing.Size(120, 22)
        Me.SHA384ToolStripMenuItem.Text = "SHA-384"
        '
        'RIPEMD160ToolStripMenuItem
        '
        Me.RIPEMD160ToolStripMenuItem.Name = "RIPEMD160ToolStripMenuItem"
        Me.RIPEMD160ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.RIPEMD160ToolStripMenuItem.Text = "Copy RIPEMD-160"
        '
        'CopyCRC32ToolStripMenuItem
        '
        Me.CopyCRC32ToolStripMenuItem.Name = "CopyCRC32ToolStripMenuItem"
        Me.CopyCRC32ToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.CopyCRC32ToolStripMenuItem.Text = "Copy CRC32"
        '
        'CopySelectedItmeToolStripMenuItem
        '
        Me.CopySelectedItmeToolStripMenuItem.Name = "CopySelectedItmeToolStripMenuItem"
        Me.CopySelectedItmeToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.CopySelectedItmeToolStripMenuItem.Text = "Copy Selected item"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(173, 6)
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.SelectAllToolStripMenuItem.Text = "Select All"
        '
        'UnSelectAllToolStripMenuItem
        '
        Me.UnSelectAllToolStripMenuItem.Name = "UnSelectAllToolStripMenuItem"
        Me.UnSelectAllToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.UnSelectAllToolStripMenuItem.Text = "UnSelect All"
        '
        'OptionToolStripMenuItem
        '
        Me.OptionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingsToolStripMenuItem, Me.TextHashToolStripMenuItem, Me.QSToolStripMenuItem})
        Me.OptionToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OptionToolStripMenuItem.Name = "OptionToolStripMenuItem"
        Me.OptionToolStripMenuItem.Size = New System.Drawing.Size(56, 20)
        Me.OptionToolStripMenuItem.Text = "Option"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.Image = CType(resources.GetObject("SettingsToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.SettingsToolStripMenuItem.Text = "Settings"
        '
        'TextHashToolStripMenuItem
        '
        Me.TextHashToolStripMenuItem.Image = CType(resources.GetObject("TextHashToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TextHashToolStripMenuItem.Name = "TextHashToolStripMenuItem"
        Me.TextHashToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.TextHashToolStripMenuItem.Text = "Text Hash"
        '
        'QSToolStripMenuItem
        '
        Me.QSToolStripMenuItem.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.Opet_Uppercasehash
        Me.QSToolStripMenuItem.CheckOnClick = True
        Me.QSToolStripMenuItem.Name = "QSToolStripMenuItem"
        Me.QSToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
        Me.QSToolStripMenuItem.Text = "Show hashes in Uppercase"
        '
        'ViewToolStripMenuItem
        '
        Me.ViewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.icontray, Me.AlwaysOnTop, Me.GridLines, Me.AutoResizeColumnsToolStripMenuItem})
        Me.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem"
        Me.ViewToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewToolStripMenuItem.Text = "View"
        '
        'icontray
        '
        Me.icontray.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.Viwe_IconTray
        Me.icontray.CheckOnClick = True
        Me.icontray.Name = "icontray"
        Me.icontray.Size = New System.Drawing.Size(181, 22)
        Me.icontray.Text = "Put icon on Tray"
        '
        'AlwaysOnTop
        '
        Me.AlwaysOnTop.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.Viwe_TopMost
        Me.AlwaysOnTop.CheckOnClick = True
        Me.AlwaysOnTop.Name = "AlwaysOnTop"
        Me.AlwaysOnTop.Size = New System.Drawing.Size(181, 22)
        Me.AlwaysOnTop.Text = "Always on Top"
        '
        'GridLines
        '
        Me.GridLines.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.Viwe_GridLines
        Me.GridLines.CheckOnClick = True
        Me.GridLines.CheckState = System.Windows.Forms.CheckState.Checked
        Me.GridLines.Name = "GridLines"
        Me.GridLines.Size = New System.Drawing.Size(181, 22)
        Me.GridLines.Text = "Grid Lines"
        '
        'AutoResizeColumnsToolStripMenuItem
        '
        Me.AutoResizeColumnsToolStripMenuItem.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.Viwe_AutoResizeColum
        Me.AutoResizeColumnsToolStripMenuItem.CheckOnClick = True
        Me.AutoResizeColumnsToolStripMenuItem.Name = "AutoResizeColumnsToolStripMenuItem"
        Me.AutoResizeColumnsToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.AutoResizeColumnsToolStripMenuItem.Text = "Auto resize columns"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem1})
        Me.AboutToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'AboutToolStripMenuItem1
        '
        Me.AboutToolStripMenuItem1.Image = CType(resources.GetObject("AboutToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.AboutToolStripMenuItem1.Name = "AboutToolStripMenuItem1"
        Me.AboutToolStripMenuItem1.Size = New System.Drawing.Size(149, 22)
        Me.AboutToolStripMenuItem1.Text = "About ACU 3.0"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Statue, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3, Me.ToolStripDropDownButton1, Me.ToolStripStatusLabel4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 374)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(871, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'Statue
        '
        Me.Statue.Name = "Statue"
        Me.Statue.Size = New System.Drawing.Size(47, 17)
        Me.Statue.Text = "0 File(s)"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(10, 17)
        Me.ToolStripStatusLabel1.Text = "|"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(68, 17)
        Me.ToolStripStatusLabel2.Text = "Selected (0)"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(10, 17)
        Me.ToolStripStatusLabel3.Text = "|"
        '
        'ToolStripDropDownButton1
        '
        Me.ToolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripDropDownButton1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.View_Details, Me.View_List, Me.View_LargeIcon, Me.View_Tile, Me.View_SmallIcon})
        Me.ToolStripDropDownButton1.Image = CType(resources.GetObject("ToolStripDropDownButton1.Image"), System.Drawing.Image)
        Me.ToolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripDropDownButton1.Name = "ToolStripDropDownButton1"
        Me.ToolStripDropDownButton1.Size = New System.Drawing.Size(29, 20)
        Me.ToolStripDropDownButton1.Text = "ToolStripDropDownButton1"
        '
        'View_Details
        '
        Me.View_Details.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.View_Details
        Me.View_Details.CheckOnClick = True
        Me.View_Details.CheckState = System.Windows.Forms.CheckState.Checked
        Me.View_Details.Name = "View_Details"
        Me.View_Details.Size = New System.Drawing.Size(129, 22)
        Me.View_Details.Text = "Details"
        Me.View_Details.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.View_Details.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'View_List
        '
        Me.View_List.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.View_List
        Me.View_List.CheckOnClick = True
        Me.View_List.Name = "View_List"
        Me.View_List.Size = New System.Drawing.Size(129, 22)
        Me.View_List.Text = "List"
        Me.View_List.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.View_List.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'View_LargeIcon
        '
        Me.View_LargeIcon.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.View_LargeIcon
        Me.View_LargeIcon.CheckOnClick = True
        Me.View_LargeIcon.Name = "View_LargeIcon"
        Me.View_LargeIcon.Size = New System.Drawing.Size(129, 22)
        Me.View_LargeIcon.Text = "Large Icon"
        Me.View_LargeIcon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.View_LargeIcon.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'View_Tile
        '
        Me.View_Tile.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.View_Tile
        Me.View_Tile.CheckOnClick = True
        Me.View_Tile.Name = "View_Tile"
        Me.View_Tile.Size = New System.Drawing.Size(129, 22)
        Me.View_Tile.Text = "Tile"
        Me.View_Tile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.View_Tile.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'View_SmallIcon
        '
        Me.View_SmallIcon.Checked = Global.Advanced_checksum_utility.My.MySettings.Default.View_Smallicon
        Me.View_SmallIcon.CheckOnClick = True
        Me.View_SmallIcon.Name = "View_SmallIcon"
        Me.View_SmallIcon.Size = New System.Drawing.Size(129, 22)
        Me.View_SmallIcon.Text = "Small Icon"
        Me.View_SmallIcon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.View_SmallIcon.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(45, 17)
        Me.ToolStripStatusLabel4.Text = "Display"
        '
        'Files_List
        '
        Me.Files_List.AllowColumnReorder = True
        Me.Files_List.AllowDrop = True
        Me.Files_List.BackColor = System.Drawing.Color.White
        Me.Files_List.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Files_List.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10})
        Me.Files_List.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Files_List.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Files_List.FullRowSelect = True
        Me.Files_List.GridLines = True
        Me.Files_List.HideSelection = False
        Me.Files_List.LabelEdit = True
        Me.Files_List.LargeImageList = Me.Img
        Me.Files_List.Location = New System.Drawing.Point(0, 24)
        Me.Files_List.Name = "Files_List"
        Me.Files_List.Size = New System.Drawing.Size(871, 350)
        Me.Files_List.SmallImageList = Me.Img
        Me.Files_List.TabIndex = 3
        Me.Files_List.UseCompatibleStateImageBehavior = False
        Me.Files_List.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "File name"
        Me.ColumnHeader1.Width = 192
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "MD5"
        Me.ColumnHeader2.Width = 211
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "SHA-1"
        Me.ColumnHeader3.Width = 177
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "SHA-256"
        Me.ColumnHeader4.Width = 177
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "CRC32"
        Me.ColumnHeader5.Width = 70
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "SHA-384"
        Me.ColumnHeader6.Width = 177
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "SHA-512"
        Me.ColumnHeader7.Width = 177
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "RIPEMD-160"
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "Full Path"
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "Extension"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddFilesToolStripMenuItem1, Me.AddFolderToolStripMenuItem1, Me.AddProcessToolStripMenuItem, Me.ToolStripSeparator7, Me.TextHashToolStripMenuItem1, Me.ToolStripSeparator10, Me.CopyToolStripMenuItem, Me.SaveToolStripMenuItem1, Me.VerifyToolStripMenuItem, Me.ToolStripSeparator8, Me.OpenInVirusTotalToolStripMenuItem1, Me.PropertiesToolStripMenuItem, Me.ToolStripSeparator9, Me.RemoveToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(172, 248)
        '
        'AddFilesToolStripMenuItem1
        '
        Me.AddFilesToolStripMenuItem1.Image = CType(resources.GetObject("AddFilesToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.AddFilesToolStripMenuItem1.Name = "AddFilesToolStripMenuItem1"
        Me.AddFilesToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.AddFilesToolStripMenuItem1.Text = "Add Files"
        '
        'AddFolderToolStripMenuItem1
        '
        Me.AddFolderToolStripMenuItem1.Image = CType(resources.GetObject("AddFolderToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.AddFolderToolStripMenuItem1.Name = "AddFolderToolStripMenuItem1"
        Me.AddFolderToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.AddFolderToolStripMenuItem1.Text = "Add Folder"
        '
        'AddProcessToolStripMenuItem
        '
        Me.AddProcessToolStripMenuItem.Image = CType(resources.GetObject("AddProcessToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AddProcessToolStripMenuItem.Name = "AddProcessToolStripMenuItem"
        Me.AddProcessToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.AddProcessToolStripMenuItem.Text = "Add Process"
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(168, 6)
        '
        'TextHashToolStripMenuItem1
        '
        Me.TextHashToolStripMenuItem1.Image = CType(resources.GetObject("TextHashToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.TextHashToolStripMenuItem1.Name = "TextHashToolStripMenuItem1"
        Me.TextHashToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.TextHashToolStripMenuItem1.Text = "Text Hash"
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(168, 6)
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyMD5ToolStripMenuItem2, Me.CopySHAToolStripMenuItem1, Me.CopyCRC32ToolStripMenuItem1, Me.CopyCRC32ToolStripMenuItem2, Me.CopySelectedItmeToolStripMenuItem2})
        Me.CopyToolStripMenuItem.Image = CType(resources.GetObject("CopyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'CopyMD5ToolStripMenuItem2
        '
        Me.CopyMD5ToolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.CopyMD5ToolStripMenuItem2.Name = "CopyMD5ToolStripMenuItem2"
        Me.CopyMD5ToolStripMenuItem2.Size = New System.Drawing.Size(176, 22)
        Me.CopyMD5ToolStripMenuItem2.Text = "Copy MD5"
        '
        'CopySHAToolStripMenuItem1
        '
        Me.CopySHAToolStripMenuItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.CopySHAToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SHA1ToolStripMenuItem2, Me.SHA256ToolStripMenuItem2, Me.SHA384ToolStripMenuItem2, Me.SHA512ToolStripMenuItem2})
        Me.CopySHAToolStripMenuItem1.Name = "CopySHAToolStripMenuItem1"
        Me.CopySHAToolStripMenuItem1.Size = New System.Drawing.Size(176, 22)
        Me.CopySHAToolStripMenuItem1.Text = "Copy SHA"
        '
        'SHA1ToolStripMenuItem2
        '
        Me.SHA1ToolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SHA1ToolStripMenuItem2.Name = "SHA1ToolStripMenuItem2"
        Me.SHA1ToolStripMenuItem2.Size = New System.Drawing.Size(120, 22)
        Me.SHA1ToolStripMenuItem2.Text = "SHA-1"
        '
        'SHA256ToolStripMenuItem2
        '
        Me.SHA256ToolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SHA256ToolStripMenuItem2.Name = "SHA256ToolStripMenuItem2"
        Me.SHA256ToolStripMenuItem2.Size = New System.Drawing.Size(120, 22)
        Me.SHA256ToolStripMenuItem2.Text = "SHA-256"
        '
        'SHA384ToolStripMenuItem2
        '
        Me.SHA384ToolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SHA384ToolStripMenuItem2.Name = "SHA384ToolStripMenuItem2"
        Me.SHA384ToolStripMenuItem2.Size = New System.Drawing.Size(120, 22)
        Me.SHA384ToolStripMenuItem2.Text = "SHA-384"
        '
        'SHA512ToolStripMenuItem2
        '
        Me.SHA512ToolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SHA512ToolStripMenuItem2.Name = "SHA512ToolStripMenuItem2"
        Me.SHA512ToolStripMenuItem2.Size = New System.Drawing.Size(120, 22)
        Me.SHA512ToolStripMenuItem2.Text = "SHA-512"
        '
        'CopyCRC32ToolStripMenuItem1
        '
        Me.CopyCRC32ToolStripMenuItem1.Name = "CopyCRC32ToolStripMenuItem1"
        Me.CopyCRC32ToolStripMenuItem1.Size = New System.Drawing.Size(176, 22)
        Me.CopyCRC32ToolStripMenuItem1.Text = "Copy RIPEMD-160"
        '
        'CopyCRC32ToolStripMenuItem2
        '
        Me.CopyCRC32ToolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.CopyCRC32ToolStripMenuItem2.Name = "CopyCRC32ToolStripMenuItem2"
        Me.CopyCRC32ToolStripMenuItem2.Size = New System.Drawing.Size(176, 22)
        Me.CopyCRC32ToolStripMenuItem2.Text = "Copy CRC32"
        '
        'CopySelectedItmeToolStripMenuItem2
        '
        Me.CopySelectedItmeToolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.CopySelectedItmeToolStripMenuItem2.Name = "CopySelectedItmeToolStripMenuItem2"
        Me.CopySelectedItmeToolStripMenuItem2.Size = New System.Drawing.Size(176, 22)
        Me.CopySelectedItmeToolStripMenuItem2.Text = "Copy Selected item"
        '
        'SaveToolStripMenuItem1
        '
        Me.SaveToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HTMLToolStripMenuItem, Me.SFVToolStripMenuItem})
        Me.SaveToolStripMenuItem1.Image = CType(resources.GetObject("SaveToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.SaveToolStripMenuItem1.Name = "SaveToolStripMenuItem1"
        Me.SaveToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.SaveToolStripMenuItem1.Text = "Save as"
        '
        'HTMLToolStripMenuItem
        '
        Me.HTMLToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem5, Me.ToolStripMenuItem4})
        Me.HTMLToolStripMenuItem.Image = CType(resources.GetObject("HTMLToolStripMenuItem.Image"), System.Drawing.Image)
        Me.HTMLToolStripMenuItem.Name = "HTMLToolStripMenuItem"
        Me.HTMLToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.HTMLToolStripMenuItem.Text = "HTML"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Image = CType(resources.GetObject("ToolStripMenuItem5.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem5.Text = "Save Selected "
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Image = CType(resources.GetObject("ToolStripMenuItem4.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem4.Text = "Save All"
        '
        'SFVToolStripMenuItem
        '
        Me.SFVToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem6, Me.ToolStripMenuItem7})
        Me.SFVToolStripMenuItem.Image = CType(resources.GetObject("SFVToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SFVToolStripMenuItem.Name = "SFVToolStripMenuItem"
        Me.SFVToolStripMenuItem.Size = New System.Drawing.Size(149, 22)
        Me.SFVToolStripMenuItem.Text = "Checksum file"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Image = CType(resources.GetObject("ToolStripMenuItem6.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem6.Text = "Save Selected "
        '
        'ToolStripMenuItem7
        '
        Me.ToolStripMenuItem7.Image = CType(resources.GetObject("ToolStripMenuItem7.Image"), System.Drawing.Image)
        Me.ToolStripMenuItem7.Name = "ToolStripMenuItem7"
        Me.ToolStripMenuItem7.Size = New System.Drawing.Size(148, 22)
        Me.ToolStripMenuItem7.Text = "Save All"
        '
        'VerifyToolStripMenuItem
        '
        Me.VerifyToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VerifySelectedToolStripMenuItem, Me.VerfyAllToolStripMenuItem, Me.VerfyFromAFileToolStripMenuItem})
        Me.VerifyToolStripMenuItem.Image = CType(resources.GetObject("VerifyToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VerifyToolStripMenuItem.Name = "VerifyToolStripMenuItem"
        Me.VerifyToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.VerifyToolStripMenuItem.Text = "Verify"
        '
        'VerifySelectedToolStripMenuItem
        '
        Me.VerifySelectedToolStripMenuItem.Name = "VerifySelectedToolStripMenuItem"
        Me.VerifySelectedToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.VerifySelectedToolStripMenuItem.Text = "Verify Selected"
        '
        'VerfyAllToolStripMenuItem
        '
        Me.VerfyAllToolStripMenuItem.Name = "VerfyAllToolStripMenuItem"
        Me.VerfyAllToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.VerfyAllToolStripMenuItem.Text = "Verify All"
        '
        'VerfyFromAFileToolStripMenuItem
        '
        Me.VerfyFromAFileToolStripMenuItem.Name = "VerfyFromAFileToolStripMenuItem"
        Me.VerfyFromAFileToolStripMenuItem.Size = New System.Drawing.Size(198, 22)
        Me.VerfyFromAFileToolStripMenuItem.Text = "Verify from a file [BETA]"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(168, 6)
        '
        'OpenInVirusTotalToolStripMenuItem1
        '
        Me.OpenInVirusTotalToolStripMenuItem1.Image = CType(resources.GetObject("OpenInVirusTotalToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.OpenInVirusTotalToolStripMenuItem1.Name = "OpenInVirusTotalToolStripMenuItem1"
        Me.OpenInVirusTotalToolStripMenuItem1.Size = New System.Drawing.Size(171, 22)
        Me.OpenInVirusTotalToolStripMenuItem1.Text = "Open in VirusTotal"
        '
        'PropertiesToolStripMenuItem
        '
        Me.PropertiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.AdvancedToolStripMenuItem})
        Me.PropertiesToolStripMenuItem.Image = CType(resources.GetObject("PropertiesToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PropertiesToolStripMenuItem.Name = "PropertiesToolStripMenuItem"
        Me.PropertiesToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.PropertiesToolStripMenuItem.Text = "Properties"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(127, 22)
        Me.ToolStripMenuItem1.Text = "Basic"
        '
        'AdvancedToolStripMenuItem
        '
        Me.AdvancedToolStripMenuItem.Name = "AdvancedToolStripMenuItem"
        Me.AdvancedToolStripMenuItem.Size = New System.Drawing.Size(127, 22)
        Me.AdvancedToolStripMenuItem.Text = "Advanced"
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(168, 6)
        '
        'RemoveToolStripMenuItem
        '
        Me.RemoveToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SelectedItmeToolStripMenuItem, Me.ClearAllToolStripMenuItem1})
        Me.RemoveToolStripMenuItem.Image = CType(resources.GetObject("RemoveToolStripMenuItem.Image"), System.Drawing.Image)
        Me.RemoveToolStripMenuItem.Name = "RemoveToolStripMenuItem"
        Me.RemoveToolStripMenuItem.Size = New System.Drawing.Size(171, 22)
        Me.RemoveToolStripMenuItem.Text = "Remove"
        '
        'SelectedItmeToolStripMenuItem
        '
        Me.SelectedItmeToolStripMenuItem.Image = CType(resources.GetObject("SelectedItmeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SelectedItmeToolStripMenuItem.Name = "SelectedItmeToolStripMenuItem"
        Me.SelectedItmeToolStripMenuItem.Size = New System.Drawing.Size(137, 22)
        Me.SelectedItmeToolStripMenuItem.Text = "Selected file"
        '
        'ClearAllToolStripMenuItem1
        '
        Me.ClearAllToolStripMenuItem1.Image = CType(resources.GetObject("ClearAllToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ClearAllToolStripMenuItem1.Name = "ClearAllToolStripMenuItem1"
        Me.ClearAllToolStripMenuItem1.Size = New System.Drawing.Size(137, 22)
        Me.ClearAllToolStripMenuItem1.Text = "Clear All"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'isAlive
        '
        Me.isAlive.Interval = 1
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(215, -30)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 7
        '
        'Panel1
        '
        Me.Panel1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(357, 144)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(206, 109)
        Me.Panel1.TabIndex = 8
        Me.Panel1.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(20, 32)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(56, 46)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(82, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Loading..."
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.NotifyIcon1.BalloonTipText = "Advanced checksum utility 3.0 "
        Me.NotifyIcon1.BalloonTipTitle = "Double Click to Show or hide the form"
        Me.NotifyIcon1.ContextMenuStrip = Me.ContextMenuStrip2
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Advanced checksum utility 3.0 "
        Me.NotifyIcon1.Visible = True
        '
        'ContextMenuStrip2
        '
        Me.ContextMenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ShowToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.ContextMenuStrip2.Name = "ContextMenuStrip2"
        Me.ContextMenuStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ContextMenuStrip2.ShowImageMargin = False
        Me.ContextMenuStrip2.Size = New System.Drawing.Size(79, 48)
        '
        'ShowToolStripMenuItem
        '
        Me.ShowToolStripMenuItem.Name = "ShowToolStripMenuItem"
        Me.ShowToolStripMenuItem.Size = New System.Drawing.Size(78, 22)
        Me.ShowToolStripMenuItem.Text = "Show"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(78, 22)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(871, 396)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Files_List)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Advanced checksum utility 3.0 "
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Img As System.Windows.Forms.ImageList
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddFilesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddFolderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddProsesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ClearAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveSelectedItmeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PropriToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents Statue As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Files_List As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents AboutToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents FsdToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenInVirusTotalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents CopySelectedItmeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CopyMD5ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopySHA1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA256ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA512ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA384ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyCRC32ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FindToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents isAlive As System.Windows.Forms.Timer
    Friend WithEvents AddFilesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddFolderToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddProcessToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents OpenInVirusTotalToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PropertiesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RemoveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SelectedItmeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearAllToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyMD5ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopySHAToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA1ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA256ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA512ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SHA384ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyCRC32ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopySelectedItmeToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents TextHashToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripDropDownButton1 As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents View_Details As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents View_List As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents View_LargeIcon As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents View_Tile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents View_SmallIcon As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents VerifyToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents SaveToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents icontray As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AlwaysOnTop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GridLines As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoResizeColumnsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnSelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdvancedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BasicToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AdvancedToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextHashToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents HTMLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SFVToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerifySelectedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerfyAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VerfyFromAFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents RIPEMD160ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyCRC32ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem12 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem13 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip2 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem

End Class
