﻿
Namespace System
    Class Encoding

    End Class
End Namespace
