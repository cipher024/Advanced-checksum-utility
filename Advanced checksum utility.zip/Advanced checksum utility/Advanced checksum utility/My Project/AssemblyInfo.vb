﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations générales relatives à un assembly dépendent de 
' l'ensemble d'attributs suivant. Changez les valeurs de ces attributs pour modifier les informations
' associées à un assembly.

' Passez en revue les valeurs des attributs de l'assembly

<Assembly: AssemblyTitle("Advanced checksum utility 3.0")> 
<Assembly: AssemblyDescription("checksum utility")> 
<Assembly: AssemblyCompany("ProxyHacker")> 
<Assembly: AssemblyProduct("Advanced checksum utility")> 
<Assembly: AssemblyCopyright("Copyright © 2012-2017 Proxy-Hacker®")> 
<Assembly: AssemblyTrademark("ProxyHacker")> 

<Assembly: ComVisible(False)>

'Le GUID suivant est pour l'ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("c0f2a7e9-d400-4c98-828a-725b050e8bc1")> 

' Les informations de version pour un assembly se composent des quatre valeurs suivantes :
'
'      Version principale
'      Version secondaire 
'      Numéro de build
'      Révision
'
' Vous pouvez spécifier toutes les valeurs ou indiquer les numéros de build et de révision par défaut 
' en utilisant '*', comme indiqué ci-dessous :
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("3.0.0.0")> 
<Assembly: AssemblyFileVersion("3.0.0.0")> 
